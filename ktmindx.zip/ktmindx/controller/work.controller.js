import express from "express";
import { workModel } from "../model/work.model.js";
import { authen } from "../middleware/authen.js";
import { author } from "../middleware/author.js";

const workRouter = express.Router();

// tạo bài
workRouter.post("/create", author, async (req, res) => {
  try {
    const { user, title, company, description } = req.body;
    // validay
    if (!user) throw new Error("not available user");
    if (!title) throw new Error("not available title");
    if (!company) throw new Error("not available company");
    if (!description) throw new Error("not available description");

    const wrok = await workModel.create({
      user,
      title,
      company,
      description,
    });

    res.status(201).send({
      data: wrok,
      message: "success",
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// xem All

workRouter.get("/admin", async (req, res) => {
  try {
    const work = await workModel.find({});
    res.status(200).send(work);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// xem theo id

workRouter.get("/search/:getId", async (req, res) => {
  try {
    const getId = req.params.getId;
    // validay
    if (!getId) throw new Error("not availabale getId");
    const work = await workModel.findById(getId);
    if (!work) throw new Error("not availabale work");
    res.status(200).send(work);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// update

workRouter.put("/update/:putId", author, async (req, res) => {
  try {
    const putId = req.params.putId;
    if (!putId) throw new Error("not available Id");

    const { user, title, company, description } = req.body;

    if (!user) throw new Error("not available user");
    if (!title) throw new Error("not available title");
    if (!company) throw new Error("not available company");
    if (!description) throw new Error("not available description");

    const work = await workModel.findByIdAndUpdate(
      putId,
      {
        user,
        title,
        company,
        description,
      },
      { new: true }
    );
    res.status(201).send(work);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// delete

workRouter.delete("/delete/:workId", author, async (req, res) => {
  try {
    const workId = req.params.workId;
    if (!workId) throw new Error("not available Id");
    const work = await workModel.findByIdAndDelete(workId);
    res.status(200).send("");
  } catch (error) {
    res.status(500).send(error.message);
  }
});

export { workRouter };
