import express from "express";
import { UserModel } from "../model/user.model.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { authen } from "../middleware/authen.js";
import { author } from "../middleware/author.js";

const userRouter = express.Router();

// đăng ký
userRouter.post("/register", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username) throw new Error("khong co username");
    if (!email) throw new Error("khong co email");
    if (!password) throw new Error("khong co password");

    //hassing password ( bam password)
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = await UserModel.create({
      username,
      email,
      password: hashedPassword,
      roles: ["admin"],
    });

    //TODO : remove password from user
    return res.status(201).send(newUser);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Login

userRouter.post("/login", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    //validation check
    if (!username && !email) throw new Error("thieu username or password");
    if (!password) throw new Error("khong co password");

    //hasing password
    //tim password qua username or email
    const user = await UserModel.findOne({
      username: req.body.username || { $ne: null },
      email: req.body.email || { $ne: null },
    });

    if (!user) throw new Error("user khong ton tai");
    //lay ra password
    const result = await bcrypt.compare(password, user.password);

    //kiem tra password
    if (!result) throw new Error("user or password that bai");

    // encode token ( mã hóa ) ( Access token + refresh token )
    const payload = {
      id: user._id.toString(),
      username: user.username,
      email: user.email,
      roles: user.roles,
    };
    //ky , them key
    var accessToken = jwt.sign(payload, process.env.JWT_ACCESS_TOKEN, {
      expiresIn: "5m",
    });
    var refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_TOKEN, {
      expiresIn: "1d",
    });

    res.status(200).send({ accessToken, refreshToken });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// refresh token

userRouter.post("/refresh", (req, res) => {
  try {
    const { refreshToken } = req.body;
    //validate
    if (!refreshToken) throw new Error("refresh token is required");

    // giai ma
    const payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_TOKEN);
    // cap lai token
    delete payload.exp; // xoa exp

    const accessToken = jwt.sign(payload, process.env.JWT_ACCESS_TOKEN, {
      expiresIn: "5m",
    });
    const newRefreshToken = jwt.sign(payload, process.env.JWT_REFRESH_TOKEN, {
      expiresIn: "1d",
    });
    return res.status(200).send({ accessToken, refreshToken: newRefreshToken });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// lay ra 1
userRouter.get("/me", authen, async (req, res) => {
  try {
    const user = await UserModel.findById(req.user.id);
    console.log("user : >>", req.user);
    res.status(200).send(user);
  } catch (error) {
    res.status(500).send("bi loi ");
  }
});

// get ALl user
userRouter.get("/admin", authen, author, async (req, res) => {
  try {
    const users = await UserModel.find({});
    res.status(200).send(users);
  } catch (error) {
    res.status(500).send("loi");
  }
});

// get 1 id

userRouter.get("/search/:userId", authen, author, async (req, res) => {
  try {
    const userId = req.params.userId;
    //validay
    if (!userId) throw new Error("not availabel id");

    const user = await UserModel.findById(userId);
    res.status(200).send(user);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// update user
userRouter.put("/update/:userId", authen, author, async (req, res) => {
  try {
    const userId = req.params.userId;
    const { username, email, password, roles } = req.body;
    // validate
    console.log("username :>>", username);
    if (!username) throw new Error("not available username");
    if (!email) throw new Error("not available email");
    if (!password) throw new Error("not available password");
    if (!roles) throw new Error("not available roles");

    const user = await UserModel.findByIdAndUpdate(
      userId,
      {
        username,
        email,
        password,
        roles,
      },
      { new: true }
    );
    res.status(201).send(
      {
        data: user,
        message: "success",
      },
      { new: true }
    );
  } catch (error) {
    res.status(500).send(error.message);
  }
});

export { userRouter };
