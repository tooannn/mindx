import express from "express";
import { profilesModel } from "../model/profiles.model.js";
import { authen } from "../middleware/authen.js";
import { author } from "../middleware/author.js";

const profilesRouter = express.Router();

// Tao profiles
profilesRouter.post("/create", authen, author, async (req, res) => {
  try {
    const { fullname, birthday, address, country } = req.body;
    if (!fullname) throw new Error(" Not available fullname");
    if (!birthday) throw new Error(" Not available bỉthday");
    if (!address) throw new Error(" Not available address");
    if (!country) throw new Error(" Not available country");

    const profiles = await profilesModel.create({
      fullname,
      birthday,
      address,
      country,
    });

    res.status(201).send({
      data: profiles,
      error: null,
      message: "success",
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// get all
profilesRouter.get("/data", authen, async (req, res) => {
  try {
    const profiles = await profilesModel.find({});
    res.status(200).send(profiles);
  } catch (error) {
    res.status(500).send("error");
  }
});

// get one

profilesRouter.get("/search/:getId", async (req, res) => {
  try {
    const getId = req.params.getId;
    //validay
    if (!getId) throw new Error("not available");
    const profiles = await profilesModel.findById(getId);
    res.status(200).send(profiles);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// cap nhat
profilesRouter.put("/update/:putId", authen, author, async (req, res) => {
  try {
    const { fullname, birthday, address, country } = req.body;
    const putId = req.params.putId;

    //validata
    if (!fullname) throw new Error("not availavel fullname");
    if (!birthday) throw new Error("not availavel birthday");
    if (!address) throw new Error("not availavel address");
    if (!country) throw new Error("not availavel country");

    //update
    const updateProfiles = await profilesModel.findByIdAndUpdate(
      putId,
      {
        fullname,
        birthday,
        address,
        country,
      },
      { new: true }
    );

    res.status(201).send(updateProfiles);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// XÓa
profilesRouter.delete("/delete/:deleteId", authen, author, async (req, res) => {
  try {
    const deleteId = req.params.deleteId;
    await profilesModel.findByIdAndDelete(deleteId);
    res.status(204).send("");
  } catch (error) {
    res.status(500).send(error.message);
  }
});

export { profilesRouter };
