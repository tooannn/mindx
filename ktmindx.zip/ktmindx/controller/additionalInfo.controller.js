import express from "express";
import { infoModel } from "../model/additionalinfo.model.js";
import { author } from "../middleware/author.js";

const infoRouter = express.Router();

// Create

infoRouter.post("/create", author, async (req, res) => {
  try {
    const { hobbies, goals } = req.body;
    //validay
    if (!hobbies) throw new Error("not anvailable hobbies");
    if (!goals) throw new Error("not anvailable goals");
    //
    const info = await infoModel.create({ hobbies, goals });
    res.status(201).send(info);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// get all

infoRouter.get("/admin", async (req, res) => {
  try {
    const info = await infoModel.find({});
    res.status(200).send(info);
  } catch (error) {
    res.status(500).send("error");
  }
});

// get 1
infoRouter.get("/search/:getId", async (req, res) => {
  try {
    const getId = req.params.getId;
    //validay
    if (!getId) throw new Error("not available Id");
    const info = await infoModel.findById(getId);
    if (!info) throw new Error("not available info");
    res.status(200).send(info);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// update

infoRouter.put("/update/:putId", author, async (req, res) => {
  try {
    const putId = req.params.putId;
    const { hobbies, goals } = req.body;
    //check validay
    if (!putId) throw new Error("not available Id");
    if (!hobbies) throw new Error("not available hobbies");
    if (!goals) throw new Error("not available goals");

    const info = await infoModel.findByIdAndUpdate(
      putId,
      { hobbies, goals },
      { new: true }
    );
    res.status(201).send(info);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// delete

infoRouter.delete("/delete/:infoId", author, async (req, res) => {
  try {
    const infoId = req.params.infoId;
    if (!infoId) throw new Error("not available Id");
    const info = await infoModel.findByIdAndDelete(infoId);
    res.status(200).send("");
  } catch (error) {
    res.status(500).send(error.message);
  }
});

export { infoRouter };
