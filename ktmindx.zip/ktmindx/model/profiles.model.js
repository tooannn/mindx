import mongoose from "mongoose";

const schema = mongoose.Schema;
const profilesSchema = new schema({
  fullname: String,
  birthday: Date,
  address: String,
  country: String,
});

const profilesModel = mongoose.model("profiles", profilesSchema);

export { profilesModel };
