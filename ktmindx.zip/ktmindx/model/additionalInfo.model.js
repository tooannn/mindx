import mongoose from "mongoose";

const Schema = mongoose.Schema;
const infoSchema = new Schema({
  hobbies: String,
  goals: String,
});

const infoModel = mongoose.model("additionalInfo", infoSchema);

export { infoModel };
