import mongoose from "mongoose";

const Schema = mongoose.Schema;
const workSchema = new Schema({
  user: String,
  title: String,
  company: String,
  description: String,
});

const workModel = mongoose.model("WorkEXperience", workSchema);

export { workModel };
