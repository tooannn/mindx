// ham authen
function author(req, res, next) {
  try {
    if (!req.user.roles?.includes("admin"))
      throw new Error("Need addmin role");
    next();
  } catch (error) {
    res.status(403).send(error.message);
  }
}

export { author };
