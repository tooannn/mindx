import jwt from "jsonwebtoken";

// ham authen
function authen(req, res, next) {
  // xac thuc nguoi dung qua token or email + password
  const token = req.headers?.authorization?.split(" ")[1];
  console.log("token : >>", token);

  // ham giai ma
  const payload = jwt.verify(token, process.env.JWT_ACCESS_TOKEN);

  // gan user vao request
  req.user = payload; // thaycho user == payload
  next()
}

export { authen };
