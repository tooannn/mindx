import mongoose from "mongoose";
import express from "express";
import dotenv from "dotenv";
import morgan from "morgan";
import { userRouter } from "./controller/user.controller.js";
import bcrypt from "bcrypt";
import { authen } from "./middleware/authen.js";
import { profilesRouter } from "./controller/profiles.controller.js";
import { workRouter } from "./controller/work.controller.js";
import { infoRouter } from "./controller/additionalInfo.controller.js";

dotenv.config();

const app = express();
app.use(express.json());
app.use(morgan("combined")); // logger

//ket noi route
app.use("/users", userRouter);
app.use("/profiles", profilesRouter);
app.use("/works", authen, workRouter);
app.use("/info", authen, infoRouter);

mongoose
  .connect(process.env.MOGODB)
  .then(() =>
    app.listen(process.env.PORT, () =>
      console.log("app run time", process.env.PORT)
    )
  );
